ENTE FAMILY BUDGET — Updated Android Browser Prototype

FIXES IN THIS VERSION
- Logo embedded directly inside index.html so it displays even if relative image paths fail.
- Item photo field allows the Android picker to offer gallery and camera options (depending on phone/browser).
- Reports default to Purchased Items Only.
- Reports can be filtered by Family Group, Recipient / Member, and status:
  Purchased Items Only / All Allocated Items / Not Purchased Yet.
- Excel-compatible CSV export, print / Save as PDF, WhatsApp share, JSON backup/restore.
- English interface except Malayalam text printed within the logo image.

OPENING
1. Extract this ZIP.
2. Open index.html in Chrome.
3. Go to Groups & Members to create groups and members.
4. Go to Shopping List, select group and recipient, add item and photo.
5. Tick the checkbox after the item is purchased.
6. Go to Reports and choose a group/member to see what was purchased for whom.

IMPORTANT
- This is a browser prototype, not an Android APK.
- Data is stored in the browser on this device. Download Backup regularly.
- Choose photos that are reasonably small; very large photos can exceed browser storage limits.
- PDF uses Print > Save as PDF. CSV can be opened in Excel.
- Currency refresh requires internet and may fail when index.html is opened as a local file; use a saved/manual rate if so.
- Test before entering important real data.
